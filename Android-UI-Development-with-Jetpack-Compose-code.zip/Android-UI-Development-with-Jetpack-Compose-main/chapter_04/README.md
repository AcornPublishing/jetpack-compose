# Chapter 4: Laying out UI Elements

<img style="-webkit-filter: drop-shadow(5px 5px 5px #222); filter: drop-shadow(5px 5px 5px #222)" src="assets/constraintlayoutdemo.png" width="20%" />
<img style="-webkit-filter: drop-shadow(5px 5px 5px #222); filter: drop-shadow(5px 5px 5px #222)" src="assets/customlayoutdemo.png" width="20%" />
<img style="-webkit-filter: drop-shadow(5px 5px 5px #222); filter: drop-shadow(5px 5px 5px #222)" src="assets/predefinedlayoutsdemo.png" width="20%" />