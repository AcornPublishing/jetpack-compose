# Chapter 9: Exploring the Interoperability APIs

<img style="-webkit-filter: drop-shadow(5px 5px 5px #222); filter: drop-shadow(5px 5px 5px #222)" src="assets/zxingdemo.png" width="20%" />
<img style="-webkit-filter: drop-shadow(5px 5px 5px #222); filter: drop-shadow(5px 5px 5px #222)" src="assets/interopdemo.png" width="20%" />