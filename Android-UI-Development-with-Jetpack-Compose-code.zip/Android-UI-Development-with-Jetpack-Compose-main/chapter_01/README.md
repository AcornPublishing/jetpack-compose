# Chapter 1: Building your first Compose App

<img style="-webkit-filter: drop-shadow(5px 5px 5px #222); filter: drop-shadow(5px 5px 5px #222)" src="assets/hello.png" width="20%" />