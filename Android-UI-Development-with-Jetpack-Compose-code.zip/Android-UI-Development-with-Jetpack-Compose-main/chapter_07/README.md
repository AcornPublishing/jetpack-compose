# Chapter 7: Tips, Tricks and Best Practices

<img style="-webkit-filter: drop-shadow(5px 5px 5px #222); filter: drop-shadow(5px 5px 5px #222)" src="assets/effectdemo.png" width="20%" />