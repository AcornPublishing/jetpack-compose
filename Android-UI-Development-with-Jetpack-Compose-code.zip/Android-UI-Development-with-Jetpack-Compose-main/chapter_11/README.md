# Chapter 11: Conclusion and Next Steps

<img style="-webkit-filter: drop-shadow(5px 5px 5px #222); filter: drop-shadow(5px 5px 5px #222)" src="assets/exposeddropdownmenuboxdemo.png" width="20%" />

<img style="-webkit-filter: drop-shadow(5px 5px 5px #222); filter: drop-shadow(5px 5px 5px #222)" src="assets/navigationraildemo.png" width="20%" />
<img style="-webkit-filter: drop-shadow(5px 5px 5px #222); filter: drop-shadow(5px 5px 5px #222)" src="assets/navigationraildemo_material3.png" width="20%" />

<img style="-webkit-filter: drop-shadow(5px 5px 5px #222); filter: drop-shadow(5px 5px 5px #222)" src="assets/composedesktopdemo.png" width="20%" />

### Please note

Depending on your local setup, you might experience an **Invalid Gradle JDK configuration found** error when opening *ComposeDesktopDemo*, which prevents the project from syncing and building. If this is the case, please click on *Change JDK* location and pick a JDK version.

<img style="-webkit-filter: drop-shadow(5px 5px 5px #222); filter: drop-shadow(5px 5px 5px #222)" src="assets/invalid_gradle_jdk.png" />
