# Chapter 10: Testing and Debugging Compose apps

<img style="-webkit-filter: drop-shadow(5px 5px 5px #222); filter: drop-shadow(5px 5px 5px #222)" src="assets/testinganddebuggingdemo.png" width="20%" />