# Chapter 5: Managing the State of your Composable Functions

<img style="-webkit-filter: drop-shadow(5px 5px 5px #222); filter: drop-shadow(5px 5px 5px #222)" src="assets/statedemo.png" width="20%" />
<img style="-webkit-filter: drop-shadow(5px 5px 5px #222); filter: drop-shadow(5px 5px 5px #222)" src="assets/flowofeventsdemo.png" width="20%" />
<img style="-webkit-filter: drop-shadow(5px 5px 5px #222); filter: drop-shadow(5px 5px 5px #222)" src="assets/viewmodeldemo.png" width="20%" />