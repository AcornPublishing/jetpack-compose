# Chapter 6: Putting the Pieces together

<img style="-webkit-filter: drop-shadow(5px 5px 5px #222); filter: drop-shadow(5px 5px 5px #222)" src="assets/composeunitconverter.png" width="20%" />