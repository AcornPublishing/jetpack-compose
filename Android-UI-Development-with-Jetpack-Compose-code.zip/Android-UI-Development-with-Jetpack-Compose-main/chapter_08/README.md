# Chapter 8: Working with Animations

<img style="-webkit-filter: drop-shadow(5px 5px 5px #222); filter: drop-shadow(5px 5px 5px #222)" src="assets/animationdemo.png" width="20%" />